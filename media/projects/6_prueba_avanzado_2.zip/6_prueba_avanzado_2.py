# Aplicacion con redireccionamiento inseguro y dependencias sin fijar
import yaml
import hashlib
import subprocess
import requests
from django.shortcuts import redirect
from django.views.decorators.csrf import csrf_exempt

DEBUG = True
CORS_ALLOW_ALL_ORIGINS = True

def redirigir_usuario(request):
    # Open redirect - usando datos de GET sin validar
    destino = request.GET.get('next')
    return redirect(destino)

def redirigir_post(request):
    # Open redirect con POST
    url = request.POST.get('url')
    return redirect(url)

@csrf_exempt
def procesar_pago(request):
    retorno = request.GET.get('return_url')
    # Redireccion sin validar origen
    return redirect(retorno)

def hashear(dato):
    # MD5 debil
    return hashlib.md5(dato.encode()).hexdigest()

def verificar(archivo):
    # SHA1 debil
    return hashlib.sha1(open(archivo,'rb').read()).hexdigest()

def consultar(url):
    # SSL desactivado
    return requests.get(url, verify=False)

def cargar_yaml(texto):
    # yaml inseguro
    return yaml.load(texto)

def ejecutar(cmd):
    subprocess.run(cmd, shell=True)